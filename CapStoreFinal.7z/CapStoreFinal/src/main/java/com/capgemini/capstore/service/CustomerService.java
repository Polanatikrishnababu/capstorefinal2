package com.capgemini.capstore.service;

import java.util.List;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.MerchantFeedback;


public interface CustomerService {
	List<MerchantFeedback> sendFeedback(MerchantFeedback bean);
	List<MerchantFeedback> viewAllFB();
	
}
