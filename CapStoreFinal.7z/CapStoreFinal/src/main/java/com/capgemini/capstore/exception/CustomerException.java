package com.capgemini.capstore.exception;

public class CustomerException {

}
