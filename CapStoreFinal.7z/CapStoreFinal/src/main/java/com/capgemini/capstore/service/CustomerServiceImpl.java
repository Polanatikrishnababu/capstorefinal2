package com.capgemini.capstore.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.MerchantFeedback;
import com.capgemini.capstore.dao.CustomerDao;

@Service("custService")
public class CustomerServiceImpl implements CustomerService {
	@Autowired
	CustomerDao customerdao;

	@Override
	public List<MerchantFeedback> sendFeedback(MerchantFeedback bean) {
		customerdao.save(bean);
		return customerdao.findAll();
	}

	@Override
	public List<MerchantFeedback> viewAllFB() {
		
		return customerdao.findAll();
	}
}
